// ==============================================================
// File generated on Tue Nov 10 21:57:48 +0800 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xhls_otsu.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHls_otsu_CfgInitialize(XHls_otsu *InstancePtr, XHls_otsu_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHls_otsu_Start(XHls_otsu *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_AP_CTRL) & 0x80;
    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHls_otsu_IsDone(XHls_otsu *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHls_otsu_IsIdle(XHls_otsu *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHls_otsu_IsReady(XHls_otsu *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHls_otsu_EnableAutoRestart(XHls_otsu *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_AP_CTRL, 0x80);
}

void XHls_otsu_DisableAutoRestart(XHls_otsu *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_AP_CTRL, 0);
}

void XHls_otsu_Set_rows(XHls_otsu *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_ROWS_DATA, Data);
}

u32 XHls_otsu_Get_rows(XHls_otsu *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_ROWS_DATA);
    return Data;
}

void XHls_otsu_Set_cols(XHls_otsu *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_COLS_DATA, Data);
}

u32 XHls_otsu_Get_cols(XHls_otsu *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_COLS_DATA);
    return Data;
}

u32 XHls_otsu_Get_otsu_th(XHls_otsu *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_OTSU_TH_DATA);
    return Data;
}

u32 XHls_otsu_Get_otsu_th_vld(XHls_otsu *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_OTSU_TH_CTRL);
    return Data & 0x1;
}

void XHls_otsu_InterruptGlobalEnable(XHls_otsu *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_GIE, 1);
}

void XHls_otsu_InterruptGlobalDisable(XHls_otsu *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_GIE, 0);
}

void XHls_otsu_InterruptEnable(XHls_otsu *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_IER);
    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_IER, Register | Mask);
}

void XHls_otsu_InterruptDisable(XHls_otsu *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_IER);
    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_IER, Register & (~Mask));
}

void XHls_otsu_InterruptClear(XHls_otsu *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHls_otsu_WriteReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_ISR, Mask);
}

u32 XHls_otsu_InterruptGetEnabled(XHls_otsu *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_IER);
}

u32 XHls_otsu_InterruptGetStatus(XHls_otsu *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHls_otsu_ReadReg(InstancePtr->Axilites_BaseAddress, XHLS_OTSU_AXILITES_ADDR_ISR);
}

