// ==============================================================
// File generated on Tue Nov 10 21:57:48 +0800 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XHLS_OTSU_H
#define XHLS_OTSU_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xhls_otsu_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Axilites_BaseAddress;
} XHls_otsu_Config;
#endif

typedef struct {
    u32 Axilites_BaseAddress;
    u32 IsReady;
} XHls_otsu;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHls_otsu_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHls_otsu_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHls_otsu_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHls_otsu_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XHls_otsu_Initialize(XHls_otsu *InstancePtr, u16 DeviceId);
XHls_otsu_Config* XHls_otsu_LookupConfig(u16 DeviceId);
int XHls_otsu_CfgInitialize(XHls_otsu *InstancePtr, XHls_otsu_Config *ConfigPtr);
#else
int XHls_otsu_Initialize(XHls_otsu *InstancePtr, const char* InstanceName);
int XHls_otsu_Release(XHls_otsu *InstancePtr);
#endif

void XHls_otsu_Start(XHls_otsu *InstancePtr);
u32 XHls_otsu_IsDone(XHls_otsu *InstancePtr);
u32 XHls_otsu_IsIdle(XHls_otsu *InstancePtr);
u32 XHls_otsu_IsReady(XHls_otsu *InstancePtr);
void XHls_otsu_EnableAutoRestart(XHls_otsu *InstancePtr);
void XHls_otsu_DisableAutoRestart(XHls_otsu *InstancePtr);

void XHls_otsu_Set_rows(XHls_otsu *InstancePtr, u32 Data);
u32 XHls_otsu_Get_rows(XHls_otsu *InstancePtr);
void XHls_otsu_Set_cols(XHls_otsu *InstancePtr, u32 Data);
u32 XHls_otsu_Get_cols(XHls_otsu *InstancePtr);
u32 XHls_otsu_Get_otsu_th(XHls_otsu *InstancePtr);
u32 XHls_otsu_Get_otsu_th_vld(XHls_otsu *InstancePtr);

void XHls_otsu_InterruptGlobalEnable(XHls_otsu *InstancePtr);
void XHls_otsu_InterruptGlobalDisable(XHls_otsu *InstancePtr);
void XHls_otsu_InterruptEnable(XHls_otsu *InstancePtr, u32 Mask);
void XHls_otsu_InterruptDisable(XHls_otsu *InstancePtr, u32 Mask);
void XHls_otsu_InterruptClear(XHls_otsu *InstancePtr, u32 Mask);
u32 XHls_otsu_InterruptGetEnabled(XHls_otsu *InstancePtr);
u32 XHls_otsu_InterruptGetStatus(XHls_otsu *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
