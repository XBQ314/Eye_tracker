// ==============================================================
// File generated on Thu Nov 12 20:56:14 +0800 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xmy_workflow.h"

extern XMy_workflow_Config XMy_workflow_ConfigTable[];

XMy_workflow_Config *XMy_workflow_LookupConfig(u16 DeviceId) {
	XMy_workflow_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMY_WORKFLOW_NUM_INSTANCES; Index++) {
		if (XMy_workflow_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMy_workflow_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMy_workflow_Initialize(XMy_workflow *InstancePtr, u16 DeviceId) {
	XMy_workflow_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMy_workflow_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMy_workflow_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

