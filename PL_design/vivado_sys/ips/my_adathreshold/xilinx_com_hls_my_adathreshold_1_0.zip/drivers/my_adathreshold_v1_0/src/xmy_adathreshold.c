// ==============================================================
// File generated on Sun Nov 08 22:39:23 +0800 2020
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmy_adathreshold.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMy_adathreshold_CfgInitialize(XMy_adathreshold *InstancePtr, XMy_adathreshold_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMy_adathreshold_Start(XMy_adathreshold *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_AP_CTRL) & 0x80;
    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMy_adathreshold_IsDone(XMy_adathreshold *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMy_adathreshold_IsIdle(XMy_adathreshold *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMy_adathreshold_IsReady(XMy_adathreshold *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMy_adathreshold_EnableAutoRestart(XMy_adathreshold *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_AP_CTRL, 0x80);
}

void XMy_adathreshold_DisableAutoRestart(XMy_adathreshold *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_AP_CTRL, 0);
}

void XMy_adathreshold_Set_height(XMy_adathreshold *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_HEIGHT_DATA, Data);
}

u32 XMy_adathreshold_Get_height(XMy_adathreshold *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_HEIGHT_DATA);
    return Data;
}

void XMy_adathreshold_Set_width(XMy_adathreshold *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_WIDTH_DATA, Data);
}

u32 XMy_adathreshold_Get_width(XMy_adathreshold *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_WIDTH_DATA);
    return Data;
}

void XMy_adathreshold_Set_threshold(XMy_adathreshold *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_THRESHOLD_DATA, Data);
}

u32 XMy_adathreshold_Get_threshold(XMy_adathreshold *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_THRESHOLD_DATA);
    return Data;
}

void XMy_adathreshold_InterruptGlobalEnable(XMy_adathreshold *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_GIE, 1);
}

void XMy_adathreshold_InterruptGlobalDisable(XMy_adathreshold *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_GIE, 0);
}

void XMy_adathreshold_InterruptEnable(XMy_adathreshold *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_IER);
    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_IER, Register | Mask);
}

void XMy_adathreshold_InterruptDisable(XMy_adathreshold *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_IER);
    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_IER, Register & (~Mask));
}

void XMy_adathreshold_InterruptClear(XMy_adathreshold *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMy_adathreshold_WriteReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_ISR, Mask);
}

u32 XMy_adathreshold_InterruptGetEnabled(XMy_adathreshold *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_IER);
}

u32 XMy_adathreshold_InterruptGetStatus(XMy_adathreshold *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMy_adathreshold_ReadReg(InstancePtr->Axilites_BaseAddress, XMY_ADATHRESHOLD_AXILITES_ADDR_ISR);
}

